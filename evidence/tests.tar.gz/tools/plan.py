#!/usr/bin/env python3
"""Finite performance supplement; protocol must exist before execution."""
import hashlib
import json
import os
from pathlib import Path
import signal
import subprocess
import time

ROOT = Path(__file__).resolve().parent.parent
OUT = ROOT / "validation/planning_v5_20261001"
EXE = ROOT / "src/a249106"
WIDTH = 8388608
CASES = [("near", 434325392), ("b9", 10**9), ("b10", 10**10),
         ("b11", 10**11), ("b12", 10**12)]
START = time.monotonic()
DEADLINE = START + 90


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def command(args, log, cap=3):
    remaining = DEADLINE - time.monotonic() - 0.5
    if remaining <= 0:
        raise RuntimeError("overall deadline")
    p = subprocess.run([str(x) for x in args], cwd=ROOT,
                       text=True, capture_output=True,
                       timeout=min(cap, remaining))
    (OUT / log).write_text(p.stdout + p.stderr)
    if p.returncode:
        raise RuntimeError(f"{args[1]} failed: {p.returncode}")
    return p.stdout


def main():
    closure = json.loads((ROOT / "src_review/A249106_v5_review_closure.json").read_text())
    if closure["external_review_status"] != "CLOSED_ON_EXACT_V5":
        raise RuntimeError("review not closed on v5")
    identity = {}
    for relative in ("src/a249106.c", "src/Makefile", "src/a249106", "data/b249106.txt"):
        actual = digest(ROOT / relative)
        if actual != closure["artifact_sha256"][relative]:
            raise RuntimeError(f"identity mismatch: {relative}")
        identity[relative] = actual
    environment = json.loads((ROOT / "validation/review04_v5_paths/environment.json").read_text())
    for path, expected in environment["runtime_sha256"].items():
        if digest(path) != expected:
            raise RuntimeError(f"dependency changed: {path}")
    cpu = next(line.split(":", 1)[1].strip()
               for line in Path("/proc/cpuinfo").read_text().splitlines()
               if line.startswith("model name"))
    if cpu != environment["cpu"]:
        raise RuntimeError("target CPU changed")
    OUT.mkdir()
    record = {"scope": "LOCAL_PERFORMANCE_CALIBRATION_ONLY", "identity": identity,
              "cpu": cpu, "runtime_sha256": environment["runtime_sha256"],
              "block": 1048576, "group": 8, "threads": 8, "width": WIDTH,
              "protocol_sha256": digest(ROOT / "validation/planning_v5_20261001_protocol.md"),
              "script_sha256": digest(__file__),
              "omp_environment": {k: os.environ.get(k) for k in
                                  ("OMP_PROC_BIND", "OMP_PLACES", "OMP_DYNAMIC", "OMP_THREAD_LIMIT")},
              "cases": []}
    try:
        for tag, low in CASES:
            if DEADLINE - time.monotonic() < 7:
                record["stopped_reason"] = "overall deadline reserve"
                break
            directory = OUT / tag
            high = low + WIDTH - 1
            command([EXE, "init", directory, low, high, 1048576, 8, 8], f"{tag}_init.log")
            budget = min(15, DEADLINE - time.monotonic() - 5)
            case = {"tag": tag, "start": low, "end": high, "next_cap_sec": budget}
            with (OUT / f"{tag}_next.log").open("w") as log:
                begin = time.monotonic()
                process = subprocess.Popen(
                    ["/usr/bin/time", "-o", str(OUT / f"{tag}_time.log"), "-f",
                     "wall_sec=%e cpu_user_sec=%U cpu_sys_sec=%S peak_rss_kib=%M",
                     str(EXE), "next", str(directory)], cwd=ROOT,
                    stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
                interrupted = False
                try:
                    returncode = process.wait(timeout=budget)
                except subprocess.TimeoutExpired:
                    interrupted = True
                    os.killpg(process.pid, signal.SIGINT)
                    try:
                        returncode = process.wait(timeout=min(1, max(0.01, DEADLINE-time.monotonic()-0.5)))
                    except subprocess.TimeoutExpired:
                        os.killpg(process.pid, signal.SIGKILL)
                        returncode = process.wait(timeout=0.5)
                case.update(returncode=returncode, interrupted=interrupted,
                            external_elapsed_sec=time.monotonic() - begin)
            if returncode == 0 and not interrupted:
                status = command([EXE, "status", directory], f"{tag}_status.log")
                verify = command([EXE, "verify", directory], f"{tag}_verify.log")
                if "COMPLETE" not in status or "COMPLETE" not in verify:
                    raise RuntimeError(f"unsealed window: {tag}")
                text = (OUT / f"{tag}_next.log").read_text()
                if "CLOSED segment=0" not in text:
                    raise RuntimeError(f"no closure: {tag}")
                case["rate_per_sec"] = WIDTH / case["external_elapsed_sec"]
                case["certified_for_calibration_only"] = True
            else:
                case["certified_for_calibration_only"] = False
            record["cases"].append(case)
            print(json.dumps(case), flush=True)
    except Exception as exc:
        record["error"] = str(exc)
        raise
    finally:
        record["total_elapsed_sec"] = time.monotonic() - START
        record["post_identity"] = {p: digest(ROOT / p) for p in identity}
        record["identity_unchanged"] = record["post_identity"] == identity
        (OUT / "measurements.json").write_text(json.dumps(record, indent=2) + "\n")
    if not record["identity_unchanged"]:
        raise RuntimeError("canonical artifact changed")


if __name__ == "__main__":
    main()
