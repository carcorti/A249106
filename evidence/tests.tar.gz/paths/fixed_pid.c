#include <sys/types.h>
#include <unistd.h>
pid_t getpid(void) { return (pid_t)2147483647; }
